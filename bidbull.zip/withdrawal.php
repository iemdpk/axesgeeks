<?php
require('top.inc.php');
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Haruf Game</h4>
				   <h4 class="box-link"><a href="manage_haruf.php">Add Haruf</a> </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
							   
							   <th>ID</th>
                                <th> wid</th>
                                <th>uid</th>
                                <th>amount </th>
                                <th> remark </th>
                                <th>status</th>
                                <th>created_at</th>
                                <th>success_at</th>           
							   <th></th>
							</tr>
						 </thead>
						 <tbody>

            <?php

            $sd = mysqli_query($con, "SELECT * FROM `withdrawals` WHERE `status` = '1'");
            while ( $rd = mysqli_fetch_array($sd)) {
                
            
            ?>
            <tr>
                <td><?php echo $rd['id'];?></td>
                <td><?php echo $rd['wid'];?></td>
                 <td><?php echo $rd['uid'];?></td>
                 <td><?php echo $rd['amount'];?></td>
                 <td><?php echo $rd['remark'];?></td>
                <td><?php echo $rd['status'];?></td>
                 <td><?php echo $rd['created_at'];?></td>
                 <td><?php echo $rd['success_at'];?></td>
                	<td><?php 

                    if($rd['status'] == 2){
                        echo "<span style='color: green;'>Success</span>";
                    }else if($rd['status'] == 1){
                        echo "<span style='color: orange;'>Pending</span>";
                    }else {
                        echo "<span style='color: red;'>Failed</span>";
                    }
                ?></td>

                <td><a href="./update-withdraw?refid=<?php echo $rd['wid'];?>"><button class="btn btn-warning btn-sm" style="color: #fff;">Edit</button></a></td>
                
            </tr>
            
            <?php
            }
            ?>
            


						
							   </td>
							</tr>
						
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>