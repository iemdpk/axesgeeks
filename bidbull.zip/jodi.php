<?php
require('top.inc.php');

if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='status'){
		$operation=get_safe_value($con,$_GET['operation']);
		$id=get_safe_value($con,$_GET['id']);
		if($operation=='active'){
			$status='1';
		}else{
			$status='0';
		}
		$update_status_sql="update jodi set status='$status' where id='$id'";
		mysqli_query($con,$update_status_sql);
	}
	
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$delete_sql="delete from jodi where id='$id'";
		mysqli_query($con,$delete_sql);
	}
}

$sql="select * from jodi order by id asc";
$res=mysqli_query($con,$sql);
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Haruf Game</h4>
				   <h4 class="box-link"><a href="manage_haruf.php">Add Jodi</a> </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
							   <th class="serial">#</th>
							   <th>ID</th>
							    
							     <th>t00</th>
							      <th>t01</th>

							       <th>t02</th>
							       <th>t03</th>
							        <th>t04</th>
							        <th>t05</th>
							         <th>t06</th>
							         <th>t07</th>
							         <th>t08</th>
							          <th>t09</th>
							           <th>t10</th>
							           	<th>t11</th>
							           <th>t12</th>
							           	<th>t13</th>
							           	 <th>t14</th> 
							           	 <th>t15</th>
							           	<th>t16</th>
							           	 <th>t17<th>
							           	 <th>t18</th
							           	 <th>t19</th>
							           	 <th>t20</th>
							           	<th>t21</th> 
							           	 <th>t22</th>
							          <th>t23</th>
							           <th>t24</th>
							           	<th>t25</th>
							           	<th>t26</th
							           	<th>t27</th
							           <th>t28</th
                                        <th>t29</th>
							          <th>t30</th>
							          <th>t31</th>
							          <th>t32</th>
							          <th>t33</th> 
							          	<th>t34</th>
							          	 <th>t35</th>
							           <th>t36</th>
							            <th>t37</th>
							             <th>t38</th>
							            <th>t39</th>
							             <th>t40</th> <th>t41</th> <th>t42</th> <th>t43</th> <th>t44</th> <th>t45</th> <th>t46</th> <th>t47</th> <th>t48</th> <th>t49</th> <th>t50</th> <th>t51</th> <th>t52</th> <th>t53</th> <th>t54</th> <th>t55</th> <th>t56</th> <th>t57</th> <th>t58</th> <th>t59</th> <th>t60</th> <th>t61</th> <th>t62</th> <th>t63</th> <th>t64</th> <th>t65</th> <th>t66</th> <th>t67</th> <th>t68</th> <th>t69</th> <th>t70</th> <th>t71</th> <th>t72</th> <th>t73</th> <th>t74</th> <th>t75</th> <th>t76</th> <th>t77</th> <th>t78</th> <th>t79</th> <th>t80</th> <th>t81</th> <th>t82</th> <th>t83</th> <th>t84</th> <th>t85</th> <th>t86</th> <th>t87</th> <th>t88</th> <th>t89</th> <th>t90</th> <th>t91</th> <th>t92</th> <th>t93</th> <th>t94</th> <th>t95</th> <th>t96</th> <th>t97</th> <th>t98</th> <th>t99</th> <th>t100</th> <th>RegisterContact</th> <th>Created_at</th>
							   <th></th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td class="serial"><?php echo $i?></td>
							   <td><?php echo $row['id']?></td>
							   <td><?php echo $row['t00']?></td>
							   <td><?php echo $row['t01']?></td>
							   <td><?php echo $row['t02']?></td>
							   <td><?php echo $row['t03']?></td>
							   <td><?php echo $row['t04']?></td>
							   <td><?php echo $row['t05']?></td>
							   <td><?php echo $row['t06']?></td>
							   <td><?php echo $row['t07']?></td>
							   <td><?php echo $row['t08']?></td>
							   <td><?php echo $row['t09']?></td>
							   <td><?php echo $row['t10']?></td>
							   <td><?php echo $row['t11']?></td>
							   <td><?php echo $row['t12']?></td>
							   <td><?php echo $row['t13']?></td>
							   <td><?php echo $row['t14']?></td>
							   <td><?php echo $row['t15']?></td>
							   <td><?php echo $row['t16']?></td>
							   <td><?php echo $row['t17']?></td>
							   <td><?php echo $row['t18']?></td>
							   <td><?php echo $row['t19']?></td>
							   <td><?php echo $row['t20']?></td>
							   <td><?php echo $row['t21']?></td>
							   <td><?php echo $row['t22']?></td>
							   <td><?php echo $row['t23']?></td>
							   <td><?php echo $row['t24']?></td>
							   <td><?php echo $row['t25']?></td>
							   <td><?php echo $row['t26']?></td>
							   <td><?php echo $row['t27']?></td>
							   <td><?php echo $row['t28']?></td>
							   <td><?php echo $row['t29']?></td>
							   <td><?php echo $row['t30']?></td>
							   <td><?php echo $row['t31']?></td>
							   <td><?php echo $row['t32']?></td>
							   <td><?php echo $ro2['t33']?></td>
							   <td><?php echo $row['t34']?></td>
							   <td><?php echo $row['t35']?></td>
							   <td><?php echo $row['t36']?></td>
							   <td><?php echo $row['t37']?></td>
							   <td><?php echo $row['t38']?></td>
							   <td><?php echo $row['t39']?></td>
							   <td><?php echo $row['t40']?></td>
							   <td><?php echo $row['t41']?></td>
							   <td><?php echo $row['t42']?></td>
							   <td><?php echo $row['t43']?></td>
							   <td><?php echo $row['t44']?></td>
							   <td><?php echo $row['t45']?></td>
							    <td><?php echo $row['t46']?></td>
							   <td><?php echo $row['t47']?></td>
							   <td><?php echo $row['t48']?></td>
							   <td><?php echo $row['t49']?></td>
							   <td><?php echo $row['t50']?></td>
							   <td><?php echo $row['t51']?></td>
							   <td><?php echo $row['t52']?></td>
							   <td><?php echo $row['t53']?></td>
							   <td><?php echo $row['t54']?></td>
							   <td><?php echo $row['t55']?></td>
							   <td><?php echo $row['t56']?></td>
							   <td><?php echo $row['t57']?></td>
							   <td><?php echo $row['t58']?></td>
							   <td><?php echo $row['t59']?></td>
							   <td><?php echo $row['t60']?></td>
							   <td><?php echo $row['t61']?></td>
							   <td><?php echo $row['t62']?></td>
							   <td><?php echo $row['t63']?></td>
							   <td><?php echo $row['t64']?></td>
							   <td><?php echo $row['t65']?></td>
							   <td><?php echo $row['t67']?></td>
							   <td><?php echo $row['t68']?></td>
							   <td><?php echo $row['t69']?></td>
							   <td><?php echo $row['t70']?></td>
							   <td><?php echo $row['t71']?></td>
							   <td><?php echo $row['t72']?></td>
							   <td><?php echo $row['t73']?></td>
							   <td><?php echo $row['t74']?></td>
							   <td><?php echo $row['t75']?></td>
							   <td><?php echo $row['t76']?></td>
							   <td><?php echo $row['t78']?></td>
							   <td><?php echo $row['t79']?></td>
							   <td><?php echo $row['t80']?></td>
							   <td><?php echo $row['t81']?></td>
							   <td><?php echo $row['t82']?></td>
							   <td><?php echo $row['t83']?></td>
							   <td><?php echo $row['t84']?></td>
							   <td><?php echo $row['t85']?></td>
							   <td><?php echo $row['t86']?></td>
							   <td><?php echo $row['t87']?></td>
							   <td><?php echo $row['t88']?></td>
							   <td><?php echo $row['t89']?></td>
							   <td><?php echo $row['t90']?></td>
							   <td><?php echo $row['t91']?></td>
							    <td><?php echo $row['t92']?></td>
							   <td><?php echo $row['t93']?></td>
							   <td><?php echo $row['t94']?></td>
							   <td><?php echo $row['t95']?></td>
							   <td><?php echo $row['t96']?></td>
							   <td><?php echo $row['t97']?></td>
							   <td><?php echo $row['t98']?></td>
							   <td><?php echo $row['t99']?></td>
							   <td><?php echo $row['t100']?></td>
							   <td><?php echo $row['RegisterContact']?></td>
							   <td><?php echo $row['Created_at']?></td>
							  
							   <td>
								<?php
								if($row['status']==1){
									echo "<span class='badge badge-complete'><a href='?type=status&operation=deactive&id=".$row['id']."'>Aprove</a></span>&nbsp;";
								}else{
									echo "<span class='badge badge-pending'><a href='?type=status&operation=active&id=".$row['id']."'>Disaprove</a></span>&nbsp;";
								}
								echo "<span class='badge badge-edit'><a href='manage_haruf.php?id=".$row['id']."'>Edit</a></span>&nbsp;";
								
								echo "<span class='badge badge-delete'><a href='?type=delete&id=".$row['id']."'>Delete</a></span>";
								
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>