<?php
require('top.inc.php');

if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='status'){
		$operation=get_safe_value($con,$_GET['operation']);
		$id=get_safe_value($con,$_GET['id']);
		if($operation=='active'){
			$status='1';
		}else{
			$status='0';
		}
		$update_status_sql="update quickcross set status='$status' where id='$id'";
		mysqli_query($con,$update_status_sql);
	}
	
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$delete_sql="delete from quickcross where id='$id'";
		mysqli_query($con,$delete_sql);
	}
}

$sql="select * from quickcross order by id asc";
$res=mysqli_query($con,$sql);
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">QuickCross Game</h4>
				   <h4 class="box-link"><a href="manage_haruf.php">Add QuikcCross</a> </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
							   <th class="serial">#</th>
							   <th>ID</th>
							   <th>a1</th>
							   <th>a2</th>
							   <th>a3</th>
							   <th>a4</th>
							   <th>a5</th>
							   <th>a6</th>
							   <th>b1</th>
							   <th>b2</th>
							   <th>b3</th>
							   <th>b4</th>
							   <th>b5</th>
							   <th>b6</th>
							   <th>allpoints</th>
							   <th>registerNumber</th>
							   <th>Created_at</th>

							     

							   <th></th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td class="serial"><?php echo $i?></td>
							   <td><?php echo $row['id']?></td>
							   <td><?php echo $row['a1']?></td>
							   <td><?php echo $row['a2']?></td>
							   <td><?php echo $row['a3']?></td>
							   <td><?php echo $row['a4']?></td>
							   <td><?php echo $row['a5']?></td>
							   <td><?php echo $row['a6']?></td>
							   <td><?php echo $row['b1']?></td>
							   <td><?php echo $row['b2']?></td>
							   <td><?php echo $row['b3']?></td>
							   <td><?php echo $row['b4']?></td>
							   <td><?php echo $row['b5']?></td>
							   <td><?php echo $row['b6']?></td>
							   <td><?php echo $row['allpoints']?></td>
							   <td><?php echo $row['registerNumber']?></td>
							   <td><?php echo $row['Created_at']?></td>
							  
							  
							   <td>
								<?php
								if($row['status']==1){
									echo "<span class='badge badge-complete'><a href='?type=status&operation=deactive&id=".$row['id']."'>Aprove</a></span>&nbsp;";
								}else{
									echo "<span class='badge badge-pending'><a href='?type=status&operation=active&id=".$row['id']."'>Disaprove</a></span>&nbsp;";
								}
								echo "<span class='badge badge-edit'><a href='manage_haruf.php?id=".$row['id']."'>Edit</a></span>&nbsp;";
								
								echo "<span class='badge badge-delete'><a href='?type=delete&id=".$row['id']."'>Delete</a></span>";
								
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>